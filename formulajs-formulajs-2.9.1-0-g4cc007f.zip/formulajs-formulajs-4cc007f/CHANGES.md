All releases are described at https://github.com/formulajs/formulajs/releases
